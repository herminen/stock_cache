local uriArgs = ngx.req.get_uri_args()
local productId = uriArgs["prodId"]
local shopId = uriArgs["shopId"]

local cjson = require("cjson")

--local host = {"192.168.0.32", "192.168.0.33"}
--local hash = ngx.crc32_long(productId)
--hash = (hash % 2) + 1

local backend = "http://192.168.0.102:8080"

local prodCacheKey = "prod_key_"..productId
local shopCacheKey = "shop_key_"..shopId

local ngxCache = ngx.shared.limit_shared_cache

local producer = require("resty.kafka.producer")
local brokerList = {
    {host="192.168.0.31", port=9092},
    {host="192.168.0.32", port=9092},
    {host="192.168.0.33", port=9092}
}

local log_json = {}
log_json["headers"] = ngx.req.get_headers()  
log_json["uri_args"] = ngx.req.get_uri_args()  
log_json["body"] = ngx.req.read_body()  
log_json["http_version"] = ngx.req.http_version()  
log_json["method"] =ngx.req.get_method() 
log_json["raw_reader"] = ngx.req.raw_header()  
log_json["body_data"] = ngx.req.get_body_data()

local message = cjson.encode(log_json)
local asyncProducer = producer:new(brokerList, {producer_type = "async", max_retry = 1, batch_num = 1})

local ok, err = asyncProducer:send("log-product", productId, message)

if not ok then
    nginx.log(ngx.ERR, "kafka send error: ", err)
end

local prodCache = ngxCache:get(prodCacheKey)
local shopCache = ngxCache:get(shopCacheKey)

if "" == prodCache or nil == prodCache then
   local http = require("resty.http")
   local httpc = http:new()

   local resp, err = httpc:request_uri(backend, {
       method = "GET",
       path = "/product/getProductInfo?prodId="..productId
   })

   if not resp then
       ngx.say("request error:", err)
       return
   end

   prodCache = resp.body
   ngxCache:set(prodCacheKey, prodCache, 5 * 60)
end

if "" == shopCache or nil == shopCache then

    local http = require("resty.http")
    local httpc = http:new()

    local resp, err = httpc:request_uri(backend, {
        method = "GET",
        path = "/product/getShopInfo?shopId="..shopId
    })

    if not resp then
        ngx.say("request error:", err)
        return
    end

    shopCache = resp.body
    ngxCache:set(shopCacheKey, shopCache, 5 * 60)

end

local productCacheJSON = cjson.decode(prodCache)
local shopCacheJSON = cjson.decode(shopCache)

local context = {
	productId = productCacheJSON.id,
	productName = productCacheJSON.name,
	productPrice = productCacheJSON.price,
	productPictureList = productCacheJSON.pictureList,
	productSpecification = productCacheJSON.specification,
	productService = productCacheJSON.service,
	productColor = productCacheJSON.color,
	productSize = productCacheJSON.size,
	shopId = shopCacheJSON.id,
	shopName = shopCacheJSON.name,
	shopLevel = shopCacheJSON.level,
	shopGoodCommentRate = shopCacheJSON.goodCommentRate
}

local template = require("resty.template")
template.render("product.html", context)
