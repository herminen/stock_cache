--ngx.say("hello world!")

local uriArgs = ngx.req.get_uri_args()
local prodId = tostring(uriArgs["prodId"])
local shopId = tostring(uriArgs["shopId"])

local hash = ngx.crc32_long(prodId)
local hosts = {"192.168.0.32", "192.168.0.33"}
hash = (hash % 2) + 1

local backend = "http://"..hosts[hash]

local req = tostring(uriArgs["req"])

local http = require("resty.http")
local httpc = http:new()

ngx.log(ngx.INFO, ngx.var.request_uri)

local resp, err = httpc:request_uri(backend, {
    method = "GET",
    path = "/"..req.."?prodId="..prodId.."&shopId="..shopId
})

if not resp then
    ngx.say("request error:", err)
    return
end

ngx.say(resp.body)

httpc:close()
